<?php
if (!defined('ABSPATH')) {
    die('You are not authorized to access this');
}
?>

<p>
    <?php echo SUPER_LINKS_DISPLAY_NAME . ' - ' . TranslateHelper::getTranslate('Version') . ': ' . SUPER_LINKS_VERSION; ?>
</p>
