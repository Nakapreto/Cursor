<?php
if (!defined('ABSPATH')) {
	die('You are not authorized to access this');
}
?>
