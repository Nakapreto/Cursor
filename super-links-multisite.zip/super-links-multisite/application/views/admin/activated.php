<?php
if (!defined('ABSPATH')) {
	die('You are not authorized to access this');
}

?>

<div class="wrap">
    <div class="container">
        <div class="py-1">
            <div class="row justify-content-end">
                <div class="col-12">
					<?php
					AlertHelper::displayAlert(TranslateHelper::getTranslate('Seu Super Links foi ativado com sucesso!'));
					?>
                </div>

                <div>
                    <div class="card col-md-8">
                        <div class="card-body">
                            <h5 class="card-title text-info">Importante:</h5>
                            <div>
                                <div>
                                    Para utilizar corretamente todas as funcionalidades do Super links, acesse nossa área de membros e assista as vídeo-aulas feitas especialmente para
                                    você.
                                    <div class="mt-3">
                                        <a href="https://wpsuperlinks.top/membros" target="_blank" class="btn btn-primary btn-sm">Clique aqui para acessar</a>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <p>Na nossa área de membros, você tem acesso ao nosso suporte, caso necessite.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>